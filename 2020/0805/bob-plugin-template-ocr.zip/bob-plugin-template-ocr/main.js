/**
 * 往往各大翻译服务商的语种类型都不同，
 * 实现插件的过程中很可能需要服务商特有的语种标识符和 Bob 定义的标识符来回转换，
 * 建议以下面的方式实现，
 * `xxx` 代表服务商特有的语种标识符，请替换为真实的，
 * 具体支持的语种数量根据实际情况而定。
 * 
 * Bob 语种标识符转服务商语种标识符(以为 'zh-Hans' 为例): var lang = langMap.get('zh-Hans');
 * 服务商语种标识符转 Bob 语种标识符: var standardLang = langMapReverse.get('xxx');
 */

var items = [
    ['auto', 'xxx'],
    ['zh-Hans', 'xxx'],
    ['zh-Hant', 'xxx'],
    ['en', 'xxx'],
];

var langMap = new Map(items);
var langMapReverse = new Map(items.map(([standardLang, lang]) => [lang, standardLang]));

function supportLanguages() {
    return items.map(([standardLang, lang]) => standardLang);
}

function ocr(query, completion) {
    // 翻译成功
    // completion({'result': result});
    
    // 翻译失败
    // completion({'error': error});    
}
